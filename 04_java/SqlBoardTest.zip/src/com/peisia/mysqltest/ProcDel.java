package com.peisia.mysqltest;

public class ProcDel {

}
