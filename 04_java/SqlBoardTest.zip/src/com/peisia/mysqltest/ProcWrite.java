package com.peisia.mysqltest;

public class ProcWrite {

}
