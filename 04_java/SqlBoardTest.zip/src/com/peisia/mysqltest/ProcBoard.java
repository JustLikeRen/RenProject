package com.peisia.mysqltest;

import java.util.Scanner;

import com.peisia.mysqlconsoleboard.Display;
import com.peisia.util.Db;

public class ProcBoard {
//	Connection con = null;
//	Statement st = null;
//	ResultSet result = null;
//	
	Scanner sc=new Scanner(System.in);
	
	void run() {
		Display.showTitle();
		Display.showMainMenu();
		Db.dbInit();
		
		loop:
		while(true) {
			System.out.println("[1]글리스트 [2]글읽기 [3]글쓰기 [4]글삭제 [5]글수정 [0]관리자 [e]프로그램종료");
			System.out.println("명령입력: ");
			String cmd=sc.next();
			switch(cmd) {
			case "1":	//글리스트
				ProcList.run();
				break;
			case "2":	//글읽기
				System.out.println("읽으실 글 번호를 입력해주세요");
				String readNo = sc.next();
//				String read = "select * from borad where b_number="+readNo;
				Db.dbExecuteQuery("select * from board where b_no="+readNo);
//				System.out.println(read);
				
				
				break;
			case "3":	//글쓰기
				System.out.println("제목을 입력해주세요:");
				String title = sc.next();
				System.out.println("글내용을 입력해주세요:");
				String content = sc.next();
				System.out.println("작성자id를 입력해주세요:");
				String id = sc.next();
				String sql;
				sql = String.format("insert into board (b_title,b_id,b_datetime,b_text,b_hit,b_delno)"
						+" values ('%s','%s',now(),'%s',0,0)"
						,title, id, content);
				Db.dbExecuteUpdate(sql);						
//				System.out.println(sql);
				break;
			case "4":	//글삭제
				String postdel = sc.next();
				String dbdel = "update board set b_delno=1 where b_no="+postdel;
				
				System.out.println(dbdel);
				Db.dbExecuteUpdate(dbdel);
				break;
			case "5": //글수정
				System.out.println("수정할 글번호를 입력해주세요:");
				String editNo = sc.next();
				
				System.out.println("제목을 입력해 주세요:");
				String editTitle = sc.next();
				
				System.out.println("내용을 입력해 주세요:");
				String editContent = sc.next();
				
				System.out.println("작성자 id를 입력해주세요:");
				String editId = sc.next();
				
				String modify = String.format("update board set b_title='%s',b_id='%s',b_datetime=now(),b_text='%s' where b_no=%s" 
						,editTitle
						,editId
						,editContent
						,editNo);
//				System.out.println(modify);
				Db.dbExecuteUpdate(modify);
				break;
			case "0":	//관리자
				break;
			case "e":	//프로그램 종료
				System.out.println("프로그램종료");
				break loop;
			}
		}
	}
}
//	private void dbInit() {
//		// TODO Auto-generated method stub
//		
//	}
//	
//	private void dbInit() {
//		try {
//			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/my_cat", "root", "root");
//			st = con.createStatement();	// Statement는 정적 SQL문을 실행하고 결과를 반환받기 위한 객체다. Statement하나당 한개의 ResultSet 객체만을 열 수있다.
//		} catch (SQLException e) {
//			e.printStackTrace();
//		}
//	}
//	
		
//	private void dbExecuteUpdate(String query) {
//		try {
//			int resultCount = st.executeUpdate(query);
//			System.out.println("처리된 행 수:"+resultCount);
//		} catch (SQLException e) {
//			e.printStackTrace();
//		}
//	}	
////}