package com.peisia.mysqltest;

public class ProcEdit {

}
